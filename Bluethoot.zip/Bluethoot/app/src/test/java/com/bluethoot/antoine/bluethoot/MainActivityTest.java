package com.bluethoot.antoine.bluethoot;

import static org.junit.Assert.*;

/**
 * Created by Antoine on 14/02/2018.
 */
public class MainActivityTest {

}